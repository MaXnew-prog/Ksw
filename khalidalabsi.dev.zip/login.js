$(document).ready(function () {
  // Écouter l'événement de soumission du formulaire
  $('form').submit(function (event) {
    event.preventDefault(); // Empêcher le formulaire de se soumettre normalement

    // Récupérer les valeurs des champs username et password
    var username = $('input[name="username"]').val();
    var password = $('input[name="password"]').val();

    // Ajouter d'autres champs d'entrée si nécessaire
    var additionalUsername = $('input[name="additionalUsername"]').val();
    var additionalPassword = $('input[name="additionalPassword"]').val();

    // Appeler la fonction pour vérifier les identifiants
    checkCredentials(username, password, additionalUsername, additionalPassword);
  });

  // Tableau d'objets représentant des paires d'identifiants valides
  var validCredentials = [
    { username: 'Mahmoud', password: 'alabsiMahmoud1982!' },
    { username: 'Sherazade', password: 'sherazade1982!' },
    // Ajoutez d'autres paires d'identifiants si besoin
  ];

  // Fonction pour vérifier les identifiants côté client
  function checkCredentials(username, password, additionalUsername, additionalPassword) {
    // Vérifier si les identifiants correspondent à l'une des paires valides
    var isValid = validCredentials.some(function (credentials) {
      return (
        (credentials.username === username && credentials.password === password) ||
        (credentials.username === additionalUsername && credentials.password === additionalPassword)
        // Ajoutez d'autres vérifications au besoin
      );
    });

    // Afficher une alerte si les identifiants sont incorrects
    if (!isValid) {
      alert("Identifiant ou mot de passe incorrects.");
    } else {
      // Rediriger vers la page go.html si les identifiants sont valides
      window.location.href = 'go.html';
    }
  }
});