$(document).ready(function () {
  // Utilisez une requête AJAX pour récupérer le nom d'utilisateur du serveur
  $.ajax({
    url: 'getUsername.php',
    method: 'GET',
    success: function (response) {
      $('#usernamePlaceholder').text(response);
    },
    error: function () {
      console.error('Erreur lors de la récupération du nom d\'utilisateur');
    }
  });
});