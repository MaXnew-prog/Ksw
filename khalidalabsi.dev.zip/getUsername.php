<?php
session_start();

// Vérifiez si l'utilisateur est connecté
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    echo $username;
} else {
    echo "Utilisateur non connecté"; // ou toute valeur par défaut
}
?>